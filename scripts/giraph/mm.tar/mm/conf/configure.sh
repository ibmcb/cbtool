# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

if [ -f "${HIBENCH_CONF}/funcs.sh" ]; then
    . "${HIBENCH_CONF}/funcs.sh"
fi

# paths
BASEDIR_HDFS=${DATA_HDFS}/MM/Input

# for prepare
ROWS_OF_BLOCKS=$(setvardef ROWS_OF_BLOCKS 2) 
COLS_OF_BLOCKS=$(setvardef COLS_OF_BLOCKS 2)
TOTAL_ROWS=$(setvardef TOTAL_ROWS 10)
TOTAL_COLS=$(setvardef TOTAL_COLS 10)
SEED_BASE=$(setvardef SEED_BASE 1234567890)
NUM_MAPS=$(setvardef NUM_MAPS 16)

# for running (total)
NUM_REDS=$(setvardef NUM_REDS 48)
